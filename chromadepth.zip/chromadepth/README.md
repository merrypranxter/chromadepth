# chromadepth

> warm front, cool back. depth mapped to hue.

Chromadepth stereoscopy system. Warm colors (red, orange, yellow) are mapped to near geometry; cool colors (blue, cyan, violet) to far geometry. The eye’s natural chromatic aberration (blue focuses slightly behind red) creates a depth cue even without glasses. Optional prismatic glasses intensify the effect. Includes chromatic edge enhancement for sharper depth discontinuities.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Cycle scene (tunnel / landscape / particles) |
| `D` | Toggle depth-hue mapping direction |
| `E` | Toggle chromatic edge enhancement |
| `G` | Toggle glasses-mode (full separation) |
| `↑ / ↓` | Adjust depth range |
| `P` | Show depth buffer as grayscale |

## Named Regimes

- **Warm Front** — Standard: red near, blue far
- **Cool Front** — Inverted: blue near, red far (weird)
- **Glasses Mode** — Full chromatic separation for prismatic glasses
- **Natural** — Subtle, no-glasses depth from aberration alone
- **Edge Enhanced** — Chromatic sharpening at depth boundaries
- **Saturation Map** — Depth mapped to saturation instead of hue

## The Math

Depth-to-hue mapping:
- near (z = 0.0) → hue = 0° (red)
- far (z = 1.0) → hue = 240° (blue)
- interpolation: HSL hue = 240° · z

Chromatic aberration model:
- Eye focal length for red: f_R
- Eye focal length for blue: f_B ≈ f_R + 0.5 D
- Result: blue-focused image appears ~0.5 D behind red
- Brain interprets blue blur as greater distance

Edge enhancement:
- Compute depth gradient: ∇z
- At high gradient, increase saturation shift
- Creates color fringing at depth boundaries (reinforces cue)

## Acknowledgments

Chromatic depth cues, prismatic glasses (Chromadepth®), research by Faubert and others on chromatic stereopsis.
