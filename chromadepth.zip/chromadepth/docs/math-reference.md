# Math Reference: chromadepth

> TODO: add mathematical foundations, equations, and reference values.
