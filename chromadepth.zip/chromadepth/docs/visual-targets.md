# Visual Targets: chromadepth

> TODO: describe desired visual output, color palettes, and animation behavior.
