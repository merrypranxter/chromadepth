// Depth-to-hue mapping with HSL conversion
