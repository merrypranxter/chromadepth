// Chromadepth renderer and scene switching
