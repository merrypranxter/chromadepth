// Depth buffer generation and range control
