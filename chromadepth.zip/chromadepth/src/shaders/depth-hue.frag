// TODO: depth-hue.frag
